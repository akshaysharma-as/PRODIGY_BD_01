from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, EmailStr, Field
from typing import Dict
from uuid import uuid4, UUID

app = FastAPI()

# In-memory storage
users_db: Dict[UUID, dict] = {}

# User model
class User(BaseModel):
    name: str = Field(..., min_length=1)
    email: EmailStr
    age: int = Field(..., ge=0)

class UserOut(User):
    id: UUID

@app.post("/users", response_model=UserOut, status_code=201)
def create_user(user: User):
    user_id = uuid4()
    users_db[user_id] = user.dict()
    return {"id": user_id, **user.dict()}

@app.get("/users/{user_id}", response_model=UserOut)
def get_user(user_id: UUID):
    if user_id not in users_db:
        raise HTTPException(status_code=404, detail="User not found")
    return {"id": user_id, **users_db[user_id]}

@app.get("/users", response_model=list[UserOut])
def list_users():
    return [{"id": uid, **data} for uid, data in users_db.items()]

@app.put("/users/{user_id}", response_model=UserOut)
def update_user(user_id: UUID, user: User):
    if user_id not in users_db:
        raise HTTPException(status_code=404, detail="User not found")
    users_db[user_id] = user.dict()
    return {"id": user_id, **user.dict()}

@app.delete("/users/{user_id}", status_code=204)
def delete_user(user_id: UUID):
    if user_id not in users_db:
        raise HTTPException(status_code=404, detail="User not found")
    del users_db[user_id]
    return